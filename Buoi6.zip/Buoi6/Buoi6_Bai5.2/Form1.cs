﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Buoi6_Bai5._2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            //string ten = textNhap.Text;
            if(this.textNhap.Text == " ")
            {
                MessageBox.Show("Bạn chưa nhập dữ liệu");
            }
            else if(rdLopA.Checked)
            {
                if(this.lstLopA.Items.Contains(this.textNhap.Text))
                    MessageBox.Show("Tên đã tồn tại trong lớp A");
                this.lstLopA.Items.Add(this.textNhap.Text);
            }
            else if (rdLopB.Checked)
            {
                if (this.lstLopB.Items.Contains(this.textNhap.Text))
                    MessageBox.Show("Tên đã tồn tại trong lớp B");
                this.lstLopB.Items.Add(this.textNhap.Text);
            }
            else
            {
                MessageBox.Show("Bạn chưa chọn lớp");
            }
        }

        private void btnChuyenAB_Click(object sender, EventArgs e)
        {
            if(this.lstLopA.SelectedItems.Count>0)
            {
                if(this.lstLopB.Items.Contains(this.lstLopA.Text))
                    MessageBox.Show("Ten da ton tai trong lop B");
                else
                {
                    List<string> selctItems = new List<string>();
                    foreach (var item in lstLopA.SelectedItems)
                    {
                        selctItems.Add(item.ToString());
                    }
                    foreach (string item in selctItems)
                    {
                        lstLopB.Items.Add(item);
                        lstLopA.Items.Remove(item);
                    }
                }
            }
        }


        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult traloi;
            traloi = MessageBox.Show("Bạn có muốn thoát không?", "Trả lời", MessageBoxButtons.OKCancel);
            if (traloi == DialogResult.OK)
                Application.Exit();
        }

        private void btnChuyenBA_Click(object sender, EventArgs e)
        {
            if(this.lstLopB.SelectedItems.Count > 0)
            {
                if (this.lstLopA.Items.Contains(this.lstLopB.Text))
                    MessageBox.Show("Ten da ton tai trong lop A");
                else
                {
                    List<string> selctItems = new List<string>();
                    foreach (var item in lstLopB.SelectedItems)
                    {
                        selctItems.Add(item.ToString());
                    }
                    foreach(string item in selctItems)
                    {
                        lstLopA.Items.Add(item);
                        lstLopB.Items.Remove(item);
                    }
                }
            }
        }

        private void MoveAll(ListBox nguon, ListBox dich)
        {
            foreach(var item in nguon.SelectedItems)
                dich.Items.Add(nguon.ToString());
            nguon.Items.Clear();

        }
        private void btnAll_AB_Click(object sender, EventArgs e)
        {
            if(this.lstLopA.SelectedItems.Count > 0)
            {
                if (this.lstLopB.Items.Contains(this.lstLopA.Text))
                    MessageBox.Show("Ten da ton tai trong lop B");
                List<string> itemsToRemove = new List<string>();
                foreach(string item in  this.lstLopA.SelectedItems)
                {
                    lstLopB.Items.Add(item);
                    itemsToRemove.Add(item);
                }
                foreach(string item in itemsToRemove)
                    lstLopA.Items.Remove(item);
            }
        }

        private void btnAll_BA_Click(object sender, EventArgs e)
        {
            if(this.lstLopB.SelectedItems.Count > 0)
            {
                while (this.lstLopB.SelectedItems.Count > 0)
                {
                    if (this.lstLopA.SelectedItems.Contains(this.lstLopB.SelectedItems[0]))
                        MessageBox.Show("Loi");
                    this.lstLopA.Items.Add(this.lstLopB.SelectedItems[0].ToString());
                    this.lstLopB.Items.RemoveAt(this.lstLopB.SelectedIndex);
                }
            }
        }

        private void btnTongSV_Click(object sender, EventArgs e)
        {
            int Sum = this.lstLopA.Items.Count + this.lstLopB.Items.Count;
            MessageBox.Show("Tổng số sinh viên là: " + Sum.ToString());
        }
    }
}
