﻿namespace Buoi5_Bai4._7
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtKQ = new System.Windows.Forms.TextBox();
            this.txtNhapMang = new System.Windows.Forms.TextBox();
            this.btnXuatMang = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtTongLe = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtTongChan = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnTong = new System.Windows.Forms.Button();
            this.txtTongMang = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnTimM = new System.Windows.Forms.Button();
            this.txtMin = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtMax = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnSX = new System.Windows.Forms.Button();
            this.rdSxGiam = new System.Windows.Forms.RadioButton();
            this.rdSxTang = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnThayThe = new System.Windows.Forms.Button();
            this.txtSoThay = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtVTthay = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.btnThoat = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(72, 129);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "Kết quả:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(72, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 22);
            this.label2.TabIndex = 0;
            this.label2.Text = "Nhập Mảng:";
            // 
            // txtKQ
            // 
            this.txtKQ.Location = new System.Drawing.Point(193, 129);
            this.txtKQ.Name = "txtKQ";
            this.txtKQ.Size = new System.Drawing.Size(614, 30);
            this.txtKQ.TabIndex = 1;
            // 
            // txtNhapMang
            // 
            this.txtNhapMang.Location = new System.Drawing.Point(193, 65);
            this.txtNhapMang.Name = "txtNhapMang";
            this.txtNhapMang.Size = new System.Drawing.Size(614, 30);
            this.txtNhapMang.TabIndex = 1;
            this.txtNhapMang.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNhapMang_KeyPress);
            // 
            // btnXuatMang
            // 
            this.btnXuatMang.Location = new System.Drawing.Point(849, 40);
            this.btnXuatMang.Name = "btnXuatMang";
            this.btnXuatMang.Size = new System.Drawing.Size(127, 55);
            this.btnXuatMang.TabIndex = 2;
            this.btnXuatMang.Text = "Xuất Mảng";
            this.btnXuatMang.UseVisualStyleBackColor = true;
            this.btnXuatMang.Click += new System.EventHandler(this.btnXuatMang_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(849, 130);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(127, 55);
            this.btnReset.TabIndex = 3;
            this.btnReset.Text = "Làm Lại";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtTongLe);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txtTongChan);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.btnTong);
            this.groupBox1.Controls.Add(this.txtTongMang);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Location = new System.Drawing.Point(76, 190);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(336, 181);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tổng";
            // 
            // txtTongLe
            // 
            this.txtTongLe.Location = new System.Drawing.Point(117, 130);
            this.txtTongLe.Name = "txtTongLe";
            this.txtTongLe.Size = new System.Drawing.Size(100, 30);
            this.txtTongLe.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 133);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(81, 22);
            this.label6.TabIndex = 5;
            this.label6.Text = "Tổng Lẻ:";
            // 
            // txtTongChan
            // 
            this.txtTongChan.Location = new System.Drawing.Point(117, 87);
            this.txtTongChan.Name = "txtTongChan";
            this.txtTongChan.Size = new System.Drawing.Size(100, 30);
            this.txtTongChan.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 90);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 22);
            this.label5.TabIndex = 3;
            this.label5.Text = "Tổng Chẳn:";
            // 
            // btnTong
            // 
            this.btnTong.Location = new System.Drawing.Point(254, 42);
            this.btnTong.Name = "btnTong";
            this.btnTong.Size = new System.Drawing.Size(76, 118);
            this.btnTong.TabIndex = 2;
            this.btnTong.Text = "Tổng";
            this.btnTong.UseVisualStyleBackColor = true;
            this.btnTong.Click += new System.EventHandler(this.btnTong_Click);
            // 
            // txtTongMang
            // 
            this.txtTongMang.Location = new System.Drawing.Point(117, 39);
            this.txtTongMang.Name = "txtTongMang";
            this.txtTongMang.Size = new System.Drawing.Size(100, 30);
            this.txtTongMang.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 42);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 22);
            this.label4.TabIndex = 0;
            this.label4.Text = "Tổng Mảng:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnTimM);
            this.groupBox2.Controls.Add(this.txtMin);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.txtMax);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Location = new System.Drawing.Point(640, 190);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(336, 181);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Tìm Min Max";
            // 
            // btnTimM
            // 
            this.btnTimM.Location = new System.Drawing.Point(254, 37);
            this.btnTimM.Name = "btnTimM";
            this.btnTimM.Size = new System.Drawing.Size(76, 118);
            this.btnTimM.TabIndex = 6;
            this.btnTimM.Text = "Tìm";
            this.btnTimM.UseVisualStyleBackColor = true;
            this.btnTimM.Click += new System.EventHandler(this.btnTimM_Click);
            // 
            // txtMin
            // 
            this.txtMin.Location = new System.Drawing.Point(138, 92);
            this.txtMin.Name = "txtMin";
            this.txtMin.Size = new System.Drawing.Size(100, 30);
            this.txtMin.TabIndex = 5;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(15, 92);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(48, 22);
            this.label8.TabIndex = 4;
            this.label8.Text = "Min:";
            // 
            // txtMax
            // 
            this.txtMax.Location = new System.Drawing.Point(138, 42);
            this.txtMax.Name = "txtMax";
            this.txtMax.Size = new System.Drawing.Size(100, 30);
            this.txtMax.TabIndex = 3;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(15, 47);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 22);
            this.label7.TabIndex = 2;
            this.label7.Text = "Max:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnSX);
            this.groupBox3.Controls.Add(this.rdSxGiam);
            this.groupBox3.Controls.Add(this.rdSxTang);
            this.groupBox3.Location = new System.Drawing.Point(76, 402);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(336, 120);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Sắp Xếp";
            // 
            // btnSX
            // 
            this.btnSX.Location = new System.Drawing.Point(254, 29);
            this.btnSX.Name = "btnSX";
            this.btnSX.Size = new System.Drawing.Size(76, 75);
            this.btnSX.TabIndex = 3;
            this.btnSX.Text = "Sắp Xếp";
            this.btnSX.UseVisualStyleBackColor = true;
            this.btnSX.Click += new System.EventHandler(this.btnSX_Click);
            // 
            // rdSxGiam
            // 
            this.rdSxGiam.AutoSize = true;
            this.rdSxGiam.Location = new System.Drawing.Point(17, 70);
            this.rdSxGiam.Name = "rdSxGiam";
            this.rdSxGiam.Size = new System.Drawing.Size(142, 26);
            this.rdSxGiam.TabIndex = 1;
            this.rdSxGiam.TabStop = true;
            this.rdSxGiam.Text = "Sắp xếp Giảm";
            this.rdSxGiam.UseVisualStyleBackColor = true;
            // 
            // rdSxTang
            // 
            this.rdSxTang.AutoSize = true;
            this.rdSxTang.Location = new System.Drawing.Point(17, 38);
            this.rdSxTang.Name = "rdSxTang";
            this.rdSxTang.Size = new System.Drawing.Size(138, 26);
            this.rdSxTang.TabIndex = 0;
            this.rdSxTang.TabStop = true;
            this.rdSxTang.Text = "Sắp xếp Tăng";
            this.rdSxTang.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnThayThe);
            this.groupBox4.Controls.Add(this.txtSoThay);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.txtVTthay);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Location = new System.Drawing.Point(640, 402);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(336, 120);
            this.groupBox4.TabIndex = 6;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Thay Thế";
            // 
            // btnThayThe
            // 
            this.btnThayThe.Location = new System.Drawing.Point(254, 29);
            this.btnThayThe.Name = "btnThayThe";
            this.btnThayThe.Size = new System.Drawing.Size(76, 75);
            this.btnThayThe.TabIndex = 6;
            this.btnThayThe.Text = "Thay Thế";
            this.btnThayThe.UseVisualStyleBackColor = true;
            this.btnThayThe.Click += new System.EventHandler(this.btnThayThe_Click);
            // 
            // txtSoThay
            // 
            this.txtSoThay.Location = new System.Drawing.Point(138, 71);
            this.txtSoThay.Name = "txtSoThay";
            this.txtSoThay.Size = new System.Drawing.Size(100, 30);
            this.txtSoThay.TabIndex = 5;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(15, 74);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(96, 22);
            this.label10.TabIndex = 4;
            this.label10.Text = "Số thay thế";
            // 
            // txtVTthay
            // 
            this.txtVTthay.Location = new System.Drawing.Point(138, 35);
            this.txtVTthay.Name = "txtVTthay";
            this.txtVTthay.Size = new System.Drawing.Size(100, 30);
            this.txtVTthay.TabIndex = 3;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(15, 38);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(117, 22);
            this.label9.TabIndex = 2;
            this.label9.Text = "Vị trí thay thế";
            // 
            // btnThoat
            // 
            this.btnThoat.Location = new System.Drawing.Point(462, 534);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(127, 56);
            this.btnThoat.TabIndex = 7;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Location = new System.Drawing.Point(367, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(232, 35);
            this.label3.TabIndex = 8;
            this.label3.Text = "Mảng Số Nguyên";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1100, 622);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnXuatMang);
            this.Controls.Add(this.txtNhapMang);
            this.Controls.Add(this.txtKQ);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtKQ;
        private System.Windows.Forms.TextBox txtNhapMang;
        private System.Windows.Forms.Button btnXuatMang;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtTongLe;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtTongChan;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnTong;
        private System.Windows.Forms.TextBox txtTongMang;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnTimM;
        private System.Windows.Forms.TextBox txtMin;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtMax;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnSX;
        private System.Windows.Forms.RadioButton rdSxGiam;
        private System.Windows.Forms.RadioButton rdSxTang;
        private System.Windows.Forms.Button btnThayThe;
        private System.Windows.Forms.TextBox txtSoThay;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtVTthay;
        private System.Windows.Forms.Label label9;
    }
}

