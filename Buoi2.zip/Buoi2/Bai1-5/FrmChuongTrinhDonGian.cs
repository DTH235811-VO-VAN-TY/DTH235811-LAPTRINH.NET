namespace Bai1_5
{
    public partial class FrmChuongTrinhDonGian : Form
    {
        public FrmChuongTrinhDonGian()
        {
            InitializeComponent();

        }
    }
}
