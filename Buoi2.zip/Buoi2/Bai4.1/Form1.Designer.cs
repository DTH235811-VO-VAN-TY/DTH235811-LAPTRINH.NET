﻿namespace Bai4._1
{
    partial class from1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnTinh = new System.Windows.Forms.Button();
            this.txtS = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtN = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnTinh4_5 = new System.Windows.Forms.Button();
            this.btnTinh4_4 = new System.Windows.Forms.Button();
            this.btnTinh4_2 = new System.Windows.Forms.Button();
            this.btnTinh4_3 = new System.Windows.Forms.Button();
            this.btnTinh4_6 = new System.Windows.Forms.Button();
            this.btnTinh4_7 = new System.Windows.Forms.Button();
            this.lblDeBai = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnTinh
            // 
            this.btnTinh.BackColor = System.Drawing.Color.Yellow;
            this.btnTinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTinh.ForeColor = System.Drawing.Color.Fuchsia;
            this.btnTinh.Location = new System.Drawing.Point(27, 243);
            this.btnTinh.Name = "btnTinh";
            this.btnTinh.Size = new System.Drawing.Size(160, 66);
            this.btnTinh.TabIndex = 36;
            this.btnTinh.Text = "TÍNH 4.1";
            this.btnTinh.UseVisualStyleBackColor = false;
            this.btnTinh.Click += new System.EventHandler(this.btnTinh_Click);
            // 
            // txtS
            // 
            this.txtS.Location = new System.Drawing.Point(257, 196);
            this.txtS.Name = "txtS";
            this.txtS.Size = new System.Drawing.Size(257, 22);
            this.txtS.TabIndex = 35;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(167, 188);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(138, 38);
            this.label4.TabIndex = 34;
            this.label4.Text = "S:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtN
            // 
            this.txtN.Location = new System.Drawing.Point(257, 149);
            this.txtN.Name = "txtN";
            this.txtN.Size = new System.Drawing.Size(257, 22);
            this.txtN.TabIndex = 33;
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(167, 141);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(138, 38);
            this.label5.TabIndex = 32;
            this.label5.Text = "N:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnTinh4_5
            // 
            this.btnTinh4_5.BackColor = System.Drawing.Color.Yellow;
            this.btnTinh4_5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTinh4_5.ForeColor = System.Drawing.Color.Fuchsia;
            this.btnTinh4_5.Location = new System.Drawing.Point(97, 336);
            this.btnTinh4_5.Name = "btnTinh4_5";
            this.btnTinh4_5.Size = new System.Drawing.Size(160, 66);
            this.btnTinh4_5.TabIndex = 37;
            this.btnTinh4_5.Text = "TÍNH 4.5";
            this.btnTinh4_5.UseVisualStyleBackColor = false;
            this.btnTinh4_5.Click += new System.EventHandler(this.btnTinh4_5_Click);
            // 
            // btnTinh4_4
            // 
            this.btnTinh4_4.BackColor = System.Drawing.Color.Yellow;
            this.btnTinh4_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTinh4_4.ForeColor = System.Drawing.Color.Fuchsia;
            this.btnTinh4_4.Location = new System.Drawing.Point(612, 243);
            this.btnTinh4_4.Name = "btnTinh4_4";
            this.btnTinh4_4.Size = new System.Drawing.Size(160, 66);
            this.btnTinh4_4.TabIndex = 38;
            this.btnTinh4_4.Text = "TÍNH 4.4";
            this.btnTinh4_4.UseVisualStyleBackColor = false;
            this.btnTinh4_4.Click += new System.EventHandler(this.btnTinh4_4_Click);
            // 
            // btnTinh4_2
            // 
            this.btnTinh4_2.BackColor = System.Drawing.Color.Yellow;
            this.btnTinh4_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTinh4_2.ForeColor = System.Drawing.Color.Fuchsia;
            this.btnTinh4_2.Location = new System.Drawing.Point(224, 243);
            this.btnTinh4_2.Name = "btnTinh4_2";
            this.btnTinh4_2.Size = new System.Drawing.Size(160, 66);
            this.btnTinh4_2.TabIndex = 39;
            this.btnTinh4_2.Text = "TÍNH 4.2";
            this.btnTinh4_2.UseVisualStyleBackColor = false;
            this.btnTinh4_2.Click += new System.EventHandler(this.btnTinh4_2_Click);
            // 
            // btnTinh4_3
            // 
            this.btnTinh4_3.BackColor = System.Drawing.Color.Yellow;
            this.btnTinh4_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTinh4_3.ForeColor = System.Drawing.Color.Fuchsia;
            this.btnTinh4_3.Location = new System.Drawing.Point(419, 243);
            this.btnTinh4_3.Name = "btnTinh4_3";
            this.btnTinh4_3.Size = new System.Drawing.Size(160, 66);
            this.btnTinh4_3.TabIndex = 40;
            this.btnTinh4_3.Text = "TÍNH 4.3";
            this.btnTinh4_3.UseVisualStyleBackColor = false;
            this.btnTinh4_3.Click += new System.EventHandler(this.btnTinh4_3_Click);
            // 
            // btnTinh4_6
            // 
            this.btnTinh4_6.BackColor = System.Drawing.Color.Yellow;
            this.btnTinh4_6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTinh4_6.ForeColor = System.Drawing.Color.Fuchsia;
            this.btnTinh4_6.Location = new System.Drawing.Point(322, 336);
            this.btnTinh4_6.Name = "btnTinh4_6";
            this.btnTinh4_6.Size = new System.Drawing.Size(160, 66);
            this.btnTinh4_6.TabIndex = 41;
            this.btnTinh4_6.Text = "TÍNH 4.6";
            this.btnTinh4_6.UseVisualStyleBackColor = false;
            this.btnTinh4_6.Click += new System.EventHandler(this.btnTinh4_6_Click);
            // 
            // btnTinh4_7
            // 
            this.btnTinh4_7.BackColor = System.Drawing.Color.Yellow;
            this.btnTinh4_7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTinh4_7.ForeColor = System.Drawing.Color.Fuchsia;
            this.btnTinh4_7.Location = new System.Drawing.Point(513, 336);
            this.btnTinh4_7.Name = "btnTinh4_7";
            this.btnTinh4_7.Size = new System.Drawing.Size(160, 66);
            this.btnTinh4_7.TabIndex = 42;
            this.btnTinh4_7.Text = "TÍNH 4.7";
            this.btnTinh4_7.UseVisualStyleBackColor = false;
            this.btnTinh4_7.Click += new System.EventHandler(this.btnTinh4_7_Click);
            // 
            // lblDeBai
            // 
            this.lblDeBai.BackColor = System.Drawing.Color.Cyan;
            this.lblDeBai.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblDeBai.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDeBai.ForeColor = System.Drawing.Color.Red;
            this.lblDeBai.Location = new System.Drawing.Point(0, 0);
            this.lblDeBai.Name = "lblDeBai";
            this.lblDeBai.Size = new System.Drawing.Size(800, 104);
            this.lblDeBai.TabIndex = 43;
            this.lblDeBai.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // from1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblDeBai);
            this.Controls.Add(this.btnTinh4_7);
            this.Controls.Add(this.btnTinh4_6);
            this.Controls.Add(this.btnTinh4_3);
            this.Controls.Add(this.btnTinh4_2);
            this.Controls.Add(this.btnTinh4_4);
            this.Controls.Add(this.btnTinh4_5);
            this.Controls.Add(this.btnTinh);
            this.Controls.Add(this.txtS);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtN);
            this.Controls.Add(this.label5);
            this.Name = "from1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnTinh;
        private System.Windows.Forms.TextBox txtS;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtN;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnTinh4_5;
        private System.Windows.Forms.Button btnTinh4_4;
        private System.Windows.Forms.Button btnTinh4_2;
        private System.Windows.Forms.Button btnTinh4_3;
        private System.Windows.Forms.Button btnTinh4_6;
        private System.Windows.Forms.Button btnTinh4_7;
        private System.Windows.Forms.Label lblDeBai;
    }
}

