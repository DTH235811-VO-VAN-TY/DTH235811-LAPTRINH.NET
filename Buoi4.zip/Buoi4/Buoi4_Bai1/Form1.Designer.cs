﻿namespace Buoi4_Bai1
{
    partial class From1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnNhap = new System.Windows.Forms.Button();
            this.btnSXgiam = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.btnSXTang = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnInMang = new System.Windows.Forms.Button();
            this.btnTong = new System.Windows.Forms.Button();
            this.btnMax = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.btnSNT = new System.Windows.Forms.Button();
            this.btnSHH = new System.Windows.Forms.Button();
            this.btnMin = new System.Windows.Forms.Button();
            this.btnTBMang = new System.Windows.Forms.Button();
            this.btnUCLN = new System.Windows.Forms.Button();
            this.txtNhap = new System.Windows.Forms.TextBox();
            this.lblKQ = new System.Windows.Forms.Label();
            this.btnDemSoLe = new System.Windows.Forms.Button();
            this.btnDemSoChan = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnNhap
            // 
            this.btnNhap.Location = new System.Drawing.Point(38, 29);
            this.btnNhap.Name = "btnNhap";
            this.btnNhap.Size = new System.Drawing.Size(170, 48);
            this.btnNhap.TabIndex = 0;
            this.btnNhap.Text = "Nhập 1 phần tử";
            this.btnNhap.UseVisualStyleBackColor = true;
            this.btnNhap.Click += new System.EventHandler(this.btnNhap_Click);
            // 
            // btnSXgiam
            // 
            this.btnSXgiam.Location = new System.Drawing.Point(862, 109);
            this.btnSXgiam.Name = "btnSXgiam";
            this.btnSXgiam.Size = new System.Drawing.Size(157, 48);
            this.btnSXgiam.TabIndex = 1;
            this.btnSXgiam.Text = "Sắp xếp giảm";
            this.btnSXgiam.UseVisualStyleBackColor = true;
            this.btnSXgiam.Click += new System.EventHandler(this.btnSXgiam_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.Location = new System.Drawing.Point(862, 29);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(157, 48);
            this.btnThoat.TabIndex = 2;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // btnSXTang
            // 
            this.btnSXTang.Location = new System.Drawing.Point(862, 193);
            this.btnSXTang.Name = "btnSXTang";
            this.btnSXTang.Size = new System.Drawing.Size(157, 48);
            this.btnSXTang.TabIndex = 3;
            this.btnSXTang.Text = "Sắp xếp tăng";
            this.btnSXTang.UseVisualStyleBackColor = true;
            this.btnSXTang.Click += new System.EventHandler(this.btnSXTang_Click);
            // 
            // btnXoa
            // 
            this.btnXoa.Location = new System.Drawing.Point(674, 28);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(170, 48);
            this.btnXoa.TabIndex = 4;
            this.btnXoa.Text = "Xóa";
            this.btnXoa.UseVisualStyleBackColor = true;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // btnInMang
            // 
            this.btnInMang.Enabled = false;
            this.btnInMang.Location = new System.Drawing.Point(467, 28);
            this.btnInMang.Name = "btnInMang";
            this.btnInMang.Size = new System.Drawing.Size(170, 48);
            this.btnInMang.TabIndex = 5;
            this.btnInMang.Text = "In Mảng";
            this.btnInMang.UseVisualStyleBackColor = true;
            this.btnInMang.Click += new System.EventHandler(this.btnInMang_Click);
            // 
            // btnTong
            // 
            this.btnTong.Location = new System.Drawing.Point(862, 287);
            this.btnTong.Name = "btnTong";
            this.btnTong.Size = new System.Drawing.Size(157, 48);
            this.btnTong.TabIndex = 6;
            this.btnTong.Text = "Tổng mảng";
            this.btnTong.UseVisualStyleBackColor = true;
            this.btnTong.Click += new System.EventHandler(this.btnTong_Click);
            // 
            // btnMax
            // 
            this.btnMax.Location = new System.Drawing.Point(862, 370);
            this.btnMax.Name = "btnMax";
            this.btnMax.Size = new System.Drawing.Size(157, 48);
            this.btnMax.TabIndex = 7;
            this.btnMax.Text = "Số lớn nhất";
            this.btnMax.UseVisualStyleBackColor = true;
            this.btnMax.Click += new System.EventHandler(this.btnMax_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(255, 287);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(186, 55);
            this.button9.TabIndex = 8;
            this.button9.Text = "button9";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(38, 287);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(211, 55);
            this.button10.TabIndex = 9;
            this.button10.Text = "button10";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // btnSNT
            // 
            this.btnSNT.Location = new System.Drawing.Point(447, 287);
            this.btnSNT.Name = "btnSNT";
            this.btnSNT.Size = new System.Drawing.Size(190, 55);
            this.btnSNT.TabIndex = 10;
            this.btnSNT.Text = "Số Nguyên Tố";
            this.btnSNT.UseVisualStyleBackColor = true;
            this.btnSNT.Click += new System.EventHandler(this.btnSNT_Click);
            // 
            // btnSHH
            // 
            this.btnSHH.Location = new System.Drawing.Point(657, 287);
            this.btnSHH.Name = "btnSHH";
            this.btnSHH.Size = new System.Drawing.Size(187, 55);
            this.btnSHH.TabIndex = 11;
            this.btnSHH.Text = "Số Hoàn Hảo";
            this.btnSHH.UseVisualStyleBackColor = true;
            this.btnSHH.Click += new System.EventHandler(this.btnSHH_Click);
            // 
            // btnMin
            // 
            this.btnMin.Location = new System.Drawing.Point(657, 369);
            this.btnMin.Name = "btnMin";
            this.btnMin.Size = new System.Drawing.Size(187, 49);
            this.btnMin.TabIndex = 12;
            this.btnMin.Text = "Số Nhỏ Nhất";
            this.btnMin.UseVisualStyleBackColor = true;
            this.btnMin.Click += new System.EventHandler(this.btnMin_Click);
            // 
            // btnTBMang
            // 
            this.btnTBMang.Location = new System.Drawing.Point(416, 369);
            this.btnTBMang.Name = "btnTBMang";
            this.btnTBMang.Size = new System.Drawing.Size(221, 49);
            this.btnTBMang.TabIndex = 13;
            this.btnTBMang.Text = "Trung Bình Mảng";
            this.btnTBMang.UseVisualStyleBackColor = true;
            this.btnTBMang.Click += new System.EventHandler(this.btnTBMang_Click);
            // 
            // btnUCLN
            // 
            this.btnUCLN.Location = new System.Drawing.Point(38, 369);
            this.btnUCLN.Name = "btnUCLN";
            this.btnUCLN.Size = new System.Drawing.Size(354, 49);
            this.btnUCLN.TabIndex = 14;
            this.btnUCLN.Text = "UCLN 2 Phần tử đầu tiên";
            this.btnUCLN.UseVisualStyleBackColor = true;
            this.btnUCLN.Click += new System.EventHandler(this.btnUCLN_Click);
            // 
            // txtNhap
            // 
            this.txtNhap.Location = new System.Drawing.Point(229, 38);
            this.txtNhap.Multiline = true;
            this.txtNhap.Name = "txtNhap";
            this.txtNhap.Size = new System.Drawing.Size(221, 37);
            this.txtNhap.TabIndex = 15;
            // 
            // lblKQ
            // 
            this.lblKQ.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.lblKQ.Location = new System.Drawing.Point(43, 90);
            this.lblKQ.Name = "lblKQ";
            this.lblKQ.Size = new System.Drawing.Size(801, 183);
            this.lblKQ.TabIndex = 16;
            // 
            // btnDemSoLe
            // 
            this.btnDemSoLe.Location = new System.Drawing.Point(255, 287);
            this.btnDemSoLe.Name = "btnDemSoLe";
            this.btnDemSoLe.Size = new System.Drawing.Size(186, 55);
            this.btnDemSoLe.TabIndex = 8;
            this.btnDemSoLe.Text = "Đêm Số Lẻ";
            this.btnDemSoLe.UseVisualStyleBackColor = true;
            this.btnDemSoLe.Click += new System.EventHandler(this.btnDemSoLe_Click);
            // 
            // btnDemSoChan
            // 
            this.btnDemSoChan.Location = new System.Drawing.Point(38, 287);
            this.btnDemSoChan.Name = "btnDemSoChan";
            this.btnDemSoChan.Size = new System.Drawing.Size(211, 55);
            this.btnDemSoChan.TabIndex = 9;
            this.btnDemSoChan.Text = "Đếm Số Chẵn";
            this.btnDemSoChan.UseVisualStyleBackColor = true;
            this.btnDemSoChan.Click += new System.EventHandler(this.btnDemSoChan_Click);
            // 
            // From1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1100, 645);
            this.Controls.Add(this.lblKQ);
            this.Controls.Add(this.txtNhap);
            this.Controls.Add(this.btnUCLN);
            this.Controls.Add(this.btnTBMang);
            this.Controls.Add(this.btnMin);
            this.Controls.Add(this.btnSHH);
            this.Controls.Add(this.btnSNT);
            this.Controls.Add(this.btnDemSoChan);
            this.Controls.Add(this.btnDemSoLe);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.btnMax);
            this.Controls.Add(this.btnTong);
            this.Controls.Add(this.btnInMang);
            this.Controls.Add(this.btnXoa);
            this.Controls.Add(this.btnSXTang);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.btnSXgiam);
            this.Controls.Add(this.btnNhap);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "From1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnNhap;
        private System.Windows.Forms.Button btnSXgiam;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.Button btnSXTang;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnInMang;
        private System.Windows.Forms.Button btnTong;
        private System.Windows.Forms.Button btnMax;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button btnSNT;
        private System.Windows.Forms.Button btnSHH;
        private System.Windows.Forms.Button btnMin;
        private System.Windows.Forms.Button btnTBMang;
        private System.Windows.Forms.Button btnUCLN;
        private System.Windows.Forms.TextBox txtNhap;
        private System.Windows.Forms.Label lblKQ;
        private System.Windows.Forms.Button btnDemSoLe;
        private System.Windows.Forms.Button btnDemSoChan;
    }
}

